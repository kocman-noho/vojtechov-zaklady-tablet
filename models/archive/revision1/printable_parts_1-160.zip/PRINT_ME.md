# Printable foundation parts

CadQuery display models for PLA, Bambu Lab A1 mini, assumed 0.4 mm nozzle.
Scale is already **1:160**. Import STLs in millimetres at **100%**.
Each part is already oriented with its printing face on the bed.

- `closed_*`: print all four parts for the closed foundation.
- `cutaway_*`: print all eleven parts for the exposed foundation.
- Colors: graphite base, light-gray concrete/lower center, ivory tower,
  dark-gray cage/reinforcement, orange ducts. Print colors separately and glue.
- Start with **0.16 mm Optimal / Generic PLA**. No supports are intended;
  the cage uses short bridges between its upright rods. Inspect its layer preview.
- Foundation diameter 166.25 mm; base diameter 172 mm. Maximum 3 mm brim on base.
- Print the anchor cage first to check the delicate 1 mm rods on your printer.

Glue lower center pins into concrete sockets, then locate the concrete in the base.
For the cutaway, fit ducts before cage/mat, then glue section bars to cut faces
and the tower flange to the pedestal. Dry-fit everything before final gluing.

All 15 STLs passed CAD validity, one-solid connectivity, watertight-mesh and
bed-size checks. Both assemblies passed interference checks. Every part sliced
successfully without warnings in OrcaSlicer 2.3.2 with the A1 mini / 0.4 mm /
0.16 mm Optimal / Generic PLA profile. No physical print has been tested.

These display parts intentionally simplify and enlarge fine details. The separate
`reference` folder in the complete project contains the unexaggerated 1:1 and
uniformly scaled 1:160 reference versions, which are not in this print-only ZIP.
See `models/README.md` in the workspace for the full assembly/accuracy guide and
`models/output/preview.html` for the interactive preview.
